########################################################################################################################.
########################################################################################################################.
########################################################################################################################.
########                                                                                                        ########.
########           TRAINING ON STRATEGIES TO CALCULATE LFS SAMPLE WEIGHTS USING CALIBRATION                     ########.
########                                                                                                        ########.
########          PREPARED BY: ANTONIO R. DISCENZA - ILO DEPARTMENT OF STATISTICS - SSMU UNIT                   ########.
########                                    E.mail: discenza@ilo.org                                            ########.
########                                                                                                        ########.
########                             OPERATIONS WITH SAMPLE DATA DATAFRAMES IN R                                ########.
########                                                                                                        ########.
########################################################################################################################.
########################################################################################################################.


### Assign the new path where wqe want to store the R objects and results

setwd("W:/ILO_LFS_GSBPM/DATA/Intro_to_R_and_ReGenesees/")
getwd()



#############################################################################################################
###
###    READ DATA FROM A SPSS DATASETS AND CREATE AN R DATAFRAME USING THE PACKAGE "HAVEN"
###    help(haven)
###


LFS_SW_DER <- read.csv("W:/ILO_LFS_GSBPM/DATA/550_DERIVED_VARIABLES/2021/Quarter1/LFS_SW_2021_Q1_DER.csv")

View(LFS_SW_DER)


#############################################################################################################
###
###    READ DATA FROM A STATA DATASETS AND CREATE AN R DATAFRAME USING THE PACKAGE "HAVEN"
###    help(haven)
###


# library(haven)

# LFS_SW_DER <- read_dta("W:/2023_ILO_ITC_WEIGHTING/LFS_GSBPM_SW/DATA/550_DERIVED_VARIABLES/2021/Quarter1/LFS_SW_2021_Q1_DER.dta")

# View(LFS_SW_DER)




#############################################################################################################
###
###    SEE THE STRUCTURE OF THE DATAFRAME 

str(LFS_SW_DER)

### For example, the number of individuals can be obtained summing the column of ones "POP_0plus", i.e.
### the dummy variable that identifies the population of age 0 plus (is 1 for all individuals interviewed) 

### let's check there are no missings on that vairable 

table(LFS_SW_DER$POP_0plus, exclude = NULL) # reports NA's

### and now sum the ones

sum(LFS_SW_DER$POP_0plus)

### and must also correspond to the number of records/rows of the dataframe

dim(LFS_SW_DER)

### Individuals in the frame must have a unique identification code (INDKEY) hence let's verify it using the following instruction

length(unique(LFS_SW_DER$INDKEY))

### We can also check how many households we have interviewed by counting the unique households ids (HHKEY)

length(        unique(LFS_SW_DER$HHKEY)       )

### and the number of enumeration areas (PSUKEY)

length(unique(LFS_SW_DER$PSUKEY))

### we can also check how many regions and districts 

table(LFS_SW_DER$REGION, LFS_SW_DER$DISTRICT)

table(LFS_SW_DER$REGION, LFS_SW_DER$STRATAKEY)


### let's also check the reference period of the sample data, to be sure we are working on the desired quarter

table(LFS_SW_DER$YEAR, LFS_SW_DER$QUARTER)



#############################################################################################################
#############################################################################################################
###
###   CREATE DUMMY VARIABLES (0,1) IN R identifying males and females in twelve age groups  


###   Let's create a copy of the dataset 

tmpSD <- LFS_SW_DER 

str(tmpSD)

###   To change the format of a variable

is.character(tmpSD$REGION)

tmpSD$DOMAIN <- as.character(tmpSD$REGION)

str(tmpSD)


tmpSD$ONES <- 1

###   Create the X variables and initialize them to 0

tmpSD$X1 <- 0 
tmpSD$X2 <- 0 
tmpSD$X3 <- 0 
tmpSD$X4 <- 0 
tmpSD$X5 <- 0 
tmpSD$X6 <- 0 
tmpSD$X7 <- 0 
tmpSD$X8 <- 0 
tmpSD$X9 <- 0 
tmpSD$X10 <- 0 
tmpSD$X11 <- 0 
tmpSD$X12 <- 0 
tmpSD$X13 <- 0 
tmpSD$X14 <- 0 
tmpSD$X15 <- 0 
tmpSD$X16 <- 0 
tmpSD$X17 <- 0 
tmpSD$X18 <- 0 
tmpSD$X19 <- 0 
tmpSD$X20 <- 0 
tmpSD$X21 <- 0 
tmpSD$X22 <- 0 
tmpSD$X23 <- 0 
tmpSD$X24 <- 0 


###    For each record of the dataset, the following code will assign 1 to the X variables based on the specific conditions
###    (e.g. males age 0-14 )


tmpSD$X1[ tmpSD$AGE>=  0 & tmpSD$AGE <=14 & tmpSD$SEX==1] <- 1
tmpSD$X2[ tmpSD$AGE>= 15 & tmpSD$AGE <=19 & tmpSD$SEX==1] <- 1
tmpSD$X3[ tmpSD$AGE>= 20 & tmpSD$AGE <=24 & tmpSD$SEX==1] <- 1
tmpSD$X4[ tmpSD$AGE>= 25 & tmpSD$AGE <=29 & tmpSD$SEX==1] <- 1
tmpSD$X5[ tmpSD$AGE>= 30 & tmpSD$AGE <=34 & tmpSD$SEX==1] <- 1
tmpSD$X6[ tmpSD$AGE>= 35 & tmpSD$AGE <=39 & tmpSD$SEX==1] <- 1
tmpSD$X7[ tmpSD$AGE>= 40 & tmpSD$AGE <=44 & tmpSD$SEX==1] <- 1
tmpSD$X8[ tmpSD$AGE>= 45 & tmpSD$AGE <=49 & tmpSD$SEX==1] <- 1
tmpSD$X9[ tmpSD$AGE>= 50 & tmpSD$AGE <=54 & tmpSD$SEX==1] <- 1
tmpSD$X10[tmpSD$AGE>= 55 & tmpSD$AGE <=59 & tmpSD$SEX==1] <- 1
tmpSD$X11[tmpSD$AGE>= 60 & tmpSD$AGE <=64 & tmpSD$SEX==1] <- 1
tmpSD$X12[tmpSD$AGE>= 65                  & tmpSD$SEX==1] <- 1

tmpSD$X13[tmpSD$AGE>=  0 & tmpSD$AGE <=14 & tmpSD$SEX==2] <- 1
tmpSD$X14[tmpSD$AGE>= 15 & tmpSD$AGE <=19 & tmpSD$SEX==2] <- 1
tmpSD$X15[tmpSD$AGE>= 20 & tmpSD$AGE <=24 & tmpSD$SEX==2] <- 1
tmpSD$X16[tmpSD$AGE>= 25 & tmpSD$AGE <=29 & tmpSD$SEX==2] <- 1
tmpSD$X17[tmpSD$AGE>= 30 & tmpSD$AGE <=34 & tmpSD$SEX==2] <- 1
tmpSD$X18[tmpSD$AGE>= 35 & tmpSD$AGE <=39 & tmpSD$SEX==2] <- 1
tmpSD$X19[tmpSD$AGE>= 40 & tmpSD$AGE <=44 & tmpSD$SEX==2] <- 1
tmpSD$X20[tmpSD$AGE>= 45 & tmpSD$AGE <=49 & tmpSD$SEX==2] <- 1
tmpSD$X21[tmpSD$AGE>= 50 & tmpSD$AGE <=54 & tmpSD$SEX==2] <- 1
tmpSD$X22[tmpSD$AGE>= 55 & tmpSD$AGE <=59 & tmpSD$SEX==2] <- 1
tmpSD$X23[tmpSD$AGE>= 60 & tmpSD$AGE <=64 & tmpSD$SEX==2] <- 1
tmpSD$X24[tmpSD$AGE>= 65                  & tmpSD$SEX==2] <- 1


######################################################################################################
###  
###   TO SUMMARIZE DATA WE COULD USE THE AGGREGATE FUNCTION  
### 
######################################################################################################

### First, create a list of the Xs to be used in the next steps (useful when we have a huge number of X)

list_of_X  <- paste(rep("X",24),seq(1,24),sep="")
list_of_X 

LFS_SAMPLE_DATA_SUMMARY <- aggregate(tmpSD[, list_of_X], by = list(DOMAIN = tmpSD$DOMAIN), FUN = sum)
View(LFS_SAMPLE_DATA_SUMMARY)


######################################################################################################
###  
###   WE CAN ALSO USE FUNCTIONS OF THE PACKAGE EXPSS THAT ALLOW TO SUMMARIZE DATA USING WEIGHTS  
### 
######################################################################################################

### We can create more complex tables using the "expss" package and the magritte %>% pipe operator 
### (see https://magrittr.tidyverse.org/reference/pipe.html)

library(expss)

### we can calculate the sample size for each cell

LFS_SAMPLE_DATA_SUMMARY2 <-
  tmpSD  %>%
  tab_cols(mdset(X1 %to% X24)) %>%
  tab_rows(DOMAIN, total()) %>%
  tab_weight(ONES) %>%
  tab_stat_sum %>%
  tab_pivot() %>%
  as.data.frame()

View(LFS_SAMPLE_DATA_SUMMARY2)


### we can calculate the estimates produced using design weights for each cell

LFS_DESIGN_WEIGHT_DATA_SUMMARY <-
  tmpSD  %>%
  tab_cols(mdset(X1 %to% X24) %>%
  tab_rows(DOMAIN, total()) %>%
  tab_weight(DESIGN_WEIGHT) %>%
  tab_stat_sum %>%
  tab_pivot() %>%
  as.data.frame()
  

View(LFS_DESIGN_WEIGHT_DATA_SUMMARY)

