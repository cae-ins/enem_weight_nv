########################################################################################################################.
########################################################################################################################.
########################################################################################################################.
########                                                                                                        ########.
########           TRAINING ON STRATEGIES TO CALCULATE LFS SAMPLE WEIGHTS USING CALIBRATION                     ########.
########                                                                                                        ########.
########          PREPARED BY: ANTONIO R. DISCENZA - ILO DEPARTMENT OF STATISTICS - SSMU UNIT                   ########.
########                                    E.mail: discenza@ilo.org                                            ########.
########                                                                                                        ########.
########                             IMPORT AND EXPORT OF DATA IN R                                             ########.
########                                                                                                        ########.
########################################################################################################################.
########################################################################################################################.


#############################################################################################################
###
###    READ DATA FROM A SPSS DATASETS AND CREATE AN R DATAFRAME USING THE PACKAGE "HAVEN"
###    help(haven)
###

#  install.packages(haven)

library(haven)

population_figures_from_sav <- read_sav("W:/ILO_LFS_GSBPM/DATA/560_POPULATION_ESTIMATES/2021/Quarter1/POP_LFS_BY_REGION_SEX_12AGEGR_2021_Q1.sav")

View(population_figures_from_sav)

#  write_sav(population_figures_from_sav, "W:/ILO_LFS_GSBPM/DATA/Intro_to_R_and_ReGenesees/test_write.sav")



#############################################################################################################
###
###    READ DATA FROM A STATA DATASETS AND CREATE AN R DATAFRAME USING THE PACKAGE "HAVEN"
###    help(haven)
###


population_figures_from_dta <- read_dta("W:/ILO_LFS_GSBPM/DATA/560_POPULATION_ESTIMATES/2021/Quarter1/POP_LFS_BY_REGION_SEX_12AGEGR_2021_Q1.dta")

View(population_figures_from_dta)




#############################################################################################################
###
###    READ DATA FROM AN EXCEL FILE AND CREATE AN R DATAFRAME USING THE PACKAGE "READXL"
###    help(readxl)
###

library("readxl") 

help(read_xlsx)

population_figures_from_xlsx <- read_xlsx("W:/ILO_LFS_GSBPM/DATA/560_POPULATION_ESTIMATES/2021/Quarter1/POP_LFS_BY_REGION_SEX_12AGEGR_2021_Q1.xlsx")

View(population_figures_from_xlsx)


#############################################################################################################
###
###    READ DATA FROM A CSV FILE AND CREATE AN R DATAFRAME
###    help(read.csv)
###

###  Read the CSV file stored in the working directory 
population_figures_from_csv <- read.csv(file="W:/ILO_LFS_GSBPM/DATA/560_POPULATION_ESTIMATES/2021/Quarter1/POP_LFS_BY_REGION_SEX_12AGEGR_2021_Q1.csv", numerals="no.loss", header= TRUE, sep= ",", na.strings= NA, quote="\"", dec= ".", strip.white= TRUE, comment.char= "")

View(population_figures_from_csv)




#############################################################################################################
###
###    SAVE R DATAFRAME ON DISK 
###


### Assign the new path where wqe want to store the R objects and results

setwd("W:/ILO_LFS_GSBPM/DATA/Intro_to_R_and_ReGenesees/")
getwd()


### save a single object in the working directory (note that the name of the R object can be different from the RData file)

save( population_figures_from_csv , file = "population_figures.RData")

### Check this aspect. First let's see the objects in memory

ls()


### Delete all the objects in memory

rm(list=ls())

ls()

### load the object contained in the RData file just saved

load( file = "population_figures.RData")

### check that the R object "population_figures_from_csv" is now in memory

ls()



#############################################################################################################
###
###    EXPORT AN R DATAFRAME AS AN SPSS DATASET USING THE PACKAGE "HAVEN"
###


library(haven)

write_sav(population_figures_from_sav, "test_write.sav")


#############################################################################################################
###
###    EXPORT AN R DATAFRAME AS A DATASET USING THE PACKAGE "HAVEN"
###

library(haven)

write_dta(population_figures_from_sav, "test_write.dta")


#############################################################################################################
###
###    EXPORT AN R DATAFRAME IN AN EXCEL FILE USING THE PACKAGE "WRITEXL" 
###

library("writexl") 

write_xlsx(population_figures_from_sav, "test_write.xlsx")


#############################################################################################################
###
###    EXPORT AN R DATAFRAME AS A CSV FILE  
###

write.csv(population_figures_from_sav, file="test_write.csv")




