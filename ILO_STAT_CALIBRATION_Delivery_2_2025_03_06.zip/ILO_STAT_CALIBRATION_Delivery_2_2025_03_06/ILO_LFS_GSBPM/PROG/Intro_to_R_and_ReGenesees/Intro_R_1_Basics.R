########################################################################################################################.
########################################################################################################################.
########################################################################################################################.
########                                                                                                        ########.
########           TRAINING ON STRATEGIES TO CALCULATE LFS SAMPLE WEIGHTS USING CALIBRATION                     ########.
########                                                                                                        ########.
########          PREPARED BY: ANTONIO R. DISCENZA - ILO DEPARTMENT OF STATISTICS - SSMU UNIT                   ########.
########                                    E.mail: discenza@ilo.org                                            ########.
#######                                                                                                         ########.
########                                     INTRODUCTION TO R                                                  ########.
########                                                                                                        ########.
########################################################################################################################.
########################################################################################################################.


### Returns the file path of the current working directory.
getwd()

### Show all the objects in the environment
ls()

##############################################################################################################
###
###    CREATE SCALAR AND VECTORS 
###
##############################################################################################################


##############################################################################################################
###    
###    SCALARS 
###  


### numeric object
my_num <- 1936
my_num

### operation with numeric object
sqrt(my_num)

sqrt_my_num <- sqrt(my_num)
sqrt_my_num

### numeric object
year <- 2022
year

### operation with numeric objects
approx_age <- year - my_num
approx_age

### character object
my_char <- "Approximate age is:"
my_char

### concatenate character and numeric objects 
result <- paste(my_char, approx_age)
result

### concatenate character and numeric objects without spaces 
result1 <- paste(my_char, approx_age, sep="")
result1


##############################################################################################################
###    
###    VECTORS 

### create a vector
my_vec <- c(1, 2, 3, 4, 5)
my_vec

### operation with a vector
my_vec_times_3 <- my_vec * 3
my_vec_times_3 


### operation with vectors
my_vec_tot <- my_vec + my_vec_times_3 
my_vec_tot

### total of the values in an object
sum(my_vec_times_3)

### mean of the values in an object
my_vec_mean <- mean(my_vec)
my_vec_mean

### other statistics oo the values of the object

var(my_vec)

sd(my_vec)

### calculate the number of elements in the vector
length(my_vec)


##############################################################################################################
###
### Selecting specific elements of a vector using the index of the element
###

### select one value
my_vec_times_3[4] 

### select more values
my_vec_times_3[c(1,4)]
 

### select first and fourth element and create a new vector (reduced)
my_vec_times_3_red <- my_vec_times_3[c(1,4)]  
my_vec_times_3_red

## select more values
my_vec_times_3[c(1,4)] 

## select more values (4th and 5th element)
my_vec_times_3[2:5] 


##############################################################################################################
###
### Selecting specific elements of a vector using the value of the element
###

### select more values (all the elements with the desired value)
my_vec_times_3[my_vec_times_3>=9] 

my_vec_times_3[my_vec_times_3==9] 

my_vec_times_3[my_vec_times_3!=9] 

### use of the AND clause
my_vec_times_3[my_vec_times_3 > 3 & my_vec_times_3 <= 9] 

### use of the OR clause
my_vec_times_3[my_vec_times_3 <= 6 | my_vec_times_3 > 12] 


##############################################################################################################
###
### Replacing specific elements of a vector 
###

### put the third element in another object
third_element <- my_vec_times_3[3]
third_element 

### change the third element
my_vec_times_3
my_vec_times_3[3] <- 0
my_vec_times_3
 
### reassign the original value to the third element
my_vec_times_3[3] <- third_element
my_vec_times_3



##############################################################################################################
###
### Working with Missing data  
###

### change the third element with a missing
my_vec_tot[3] <- NA
my_vec_tot

### sum the elements (the result is NA because at least one element is NA
sum(my_vec_tot)

### sum all the elements that are not NA 
sum(my_vec_tot, na.rm = TRUE)

### summary of all the elements that are not NA 
summary(my_vec_tot, na.rm = TRUE)


##############################################################################################################
###
### SAVE the objects in the environment for future use
###


### list all the elements
ls()

### remove an element not needed
rm(result1)
ls()


##############################################################################################################
###
### Change the current working directory.
###

### Save the original path of the working directory in an object
my_wd_orig <- getwd()

### Assign the new path
setwd("W:/ILO_LFS_GSBPM/DATA/Intro_to_R_and_ReGenesees/")
getwd()

### Reassign the original working directory.
# setwd(my_wd_orig)
# getwd()



### save a single object in the working directory

save( my_vec , file = "my_vec_from_intro_R.RData")


### save the image file in the working directory
save.image(file = "S04_Intro_R.RData")

### Delete all objects
rm(list=ls())
ls()


### Reload a single objects
load(file="my_vec_from_intro_R.RData")
ls()

### Reload all the objects in the image file
load(file = "S04_Intro_R.RData")

ls()
