########################################################################################################################.
########################################################################################################################.
########################################################################################################################.
########                                                                                                        ########.
########           TRAINING ON STRATEGIES TO CALCULATE LFS SAMPLE WEIGHTS USING CALIBRATION                     ########.
########                                                                                                        ########.
########          PREPARED BY: ANTONIO R. DISCENZA - ILO DEPARTMENT OF STATISTICS - SSMU UNIT                   ########.
########                                    E.mail: discenza@ilo.org                                            ########.
########                                                                                                        ########.
########                             OPERATIONS WITH SAMPLE DATA DATAFRAMES IN R                                ########.
########                                                                                                        ########.
########################################################################################################################.
########################################################################################################################.


### Assign the new path where wqe want to store the R objects and results

setwd("W:/ILO_LFS_GSBPM/DATA/Intro_to_R_and_ReGenesees/")
getwd()



#############################################################################################################
###
###    READ DATA FROM A SPSS DATASETS AND CREATE AN R DATAFRAME USING THE PACKAGE "HAVEN"
###    help(haven)
###

library(haven)

LFS_SW_DER <- read_sav("W:/ILO_LFS_GSBPM/DATA/550_DERIVED_VARIABLES/2021/Quarter1/LFS_ILO_2021_Q1_DER.sav")

View(LFS_SW_DER)


#############################################################################################################
###
###    SEE THE STRUCTURE OF THE DATAFRAME 

str(LFS_SW_DER)



#############################################################################################################
###
###    PRODUCING WEIGHTED TABLES 
###
###    Given that we already have the design_weights attached to the sample data we can also produce weighted results
###

### An estimate of the total population obtained with design_weights can be produced simply as follows

sum(LFS_SW_DER$DESIGN_WEIGHT)


### We can create more complex tables using the "expss" package and the magritte %>% pipe operator 
### (see https://magrittr.tidyverse.org/reference/pipe.html)

library(expss)

### Here we produce a table with SEX and REGION 

LFS_SW_DER %>%
  tab_cols(SEX, total(label="Males and Females")) %>%
  tab_rows(REGION, total(label="Total Country")) %>%
  tab_weight(DESIGN_WEIGHT) %>%
  tab_stat_sum %>%
  tab_pivot()

### We can save the table as a dataframe 

tmp_TABLE_A <-
  LFS_SW_DER %>%
  tab_cols(SEX, total(label="Males and Females")) %>%
  tab_rows(REGION, total(label="Total Country")) %>%
  tab_weight(DESIGN_WEIGHT) %>%
  tab_stat_sum %>%
  tab_pivot() %>%
  as.data.frame()

View(tmp_TABLE_A)

### and then export the table to excel using the package "writexl"

library(writexl)

write_xlsx(tmp_TABLE_A,"TABLE_A_2021_Q1.xlsx")



#############################################################################################################
###
###    PRODUCING PRE-FORMATTED WEIGHTED TABLES 
###
###    We could produce complex tables ready for publication in EXCEL using the following workflow
###
###    1 - Create the table in R and save it as dataframe
###    2 - Create the empty template in excel already formatted as needed for dissemination
###    3 - Export the numbers of the table from the R dataframe to the excel template
###    4 - Save the excel file with the desired name in the desired folder on disk


#############################################################################################################
###
###    STEP 1 - Create the table in R and save it as dataframe


#############################################################################################################
###    Create labels for the variables SEX, AGE_GROUP7 and ilo_lfs  

list_labels 	<- list( 
  REGION = "REGION",
  REGION = num_lab("1 1-Region1 
                    2 2-Region2 
                    3 3-Region3 
                    4 4-Region4"),

    SEX = "Sex",
  SEX = num_lab("1 1-Males 
                                     2 2-Females"),
  
  AGE_GROUP7 = "Age in 7 groups",
  AGE_GROUP7 = num_lab("1 1 - 0-14 
                                            2 2 - 15-24
                                            3 3 - 25-34
                                            4 4 - 35-44
                                            5 5 - 45-54
                                            6 6 - 55-64
                                            7 7 - 65+"),
  
  ilo_lfs = "Labour Status",
  ilo_lfs = num_lab("1 1-Employed 
                                         2 2-Unemployed 
                                         3 3-Outside Labour Force")
)


###    Apply label to the dataframe with the sample data and create a new temporary dataframe 
###    that will be used to prepare the tables

tmp_data_DER_withlab = apply_labels(LFS_SW_DER, list_labels)

str(tmp_data_DER_withlab)

#############################################################################################################
###  create the table

tmp_TABLE_1 <-
  tmp_data_DER_withlab %>%
  tab_cols(  list(SEX,total(label="Males and Females"))    %nest%  list(ilo_lfs ,total(label="Total Population"))  )  %>%
  tab_rows(      list(REGION,total(label="Total Country"))    %nest%    list(AGE_GROUP7,total(label="Total Age Groups"))  ) %>%
  tab_weight(DESIGN_WEIGHT) %>%
  tab_stat_sum () %>%
  tab_pivot() %>%
  as.data.frame()

View(tmp_TABLE_1)

#############################################################################################################
###
###    STEP 2 - Create the empty template in excel already formatted as needed for dissemination

###    Check the empty template in the folder "LFS_GSBPM_SW\PROG\Intro_to_R_and_ReGenesees"



#############################################################################################################
###
###    STEP 3 - Export the numbers of the table from the R dataframe to the excel template
###             using the package "excel.link"

library(excel.link)

#############################################      OPEN EXCEL      #####################

xls = xl.get.excel()


#############################################      CLOSE THE DEFAULT SHEET #####################

xl.workbook.close(xl.workbook.name = NULL)



############################    OPEN THE EMPTY TEMPLATE ALREADY FORMATTED  #####################

xl.workbook.open( "W:/ILO_LFS_GSBPM/PROG/Intro_to_R_and_ReGenesees/Template_table_1.xlsx" )



######################      SET THE FIRST CELLS OF THE EMPTY TEMPLATE WHERE THE DATA WILL BE SAVED       #####################

firstcelldata = xls[["Activesheet"]]$Cells(5,4)



######################  WRITE DATA (NOT LABEL) TO THE RENAMED EMPTY TEMPLATE READING FROM THE DATAFRAME CONTAINTING THE R TABLE #####################

xl.write(as.data.frame(tmp_TABLE_1)[,seq(2,13)], firstcelldata, row.names = FALSE,col.names = FALSE)



######################    WRITE THE REFERENCE PERIOD IN THE TABLE OF THE TABLE     #####################

### Define the cell where to write the reference period

celltitle = xls[["Activesheet"]]$Cells(1,9)

### Write the reference period

xl.write("2021_Q1", celltitle)


#############################################################################################################
###
###    STEP 4 - Save the excel file with the desired name in the desired folder on disk

####################     SAVE WITH ANOTHER NAME IN A SPECIFIC FOLDER (CAN BE PARAMETERISED)     #####################

xl.workbook.save("W:/2023_ILO_ITC_WEIGHTING/LFS_GSBPM_SW/DATA/Intro_to_R_and_ReGenesees/Table_1_2021_Q1.xlsx")



######################     CLOSE THE EXCEL TABLE  #####################

xl.workbook.close(xl.workbook.name = NULL)

