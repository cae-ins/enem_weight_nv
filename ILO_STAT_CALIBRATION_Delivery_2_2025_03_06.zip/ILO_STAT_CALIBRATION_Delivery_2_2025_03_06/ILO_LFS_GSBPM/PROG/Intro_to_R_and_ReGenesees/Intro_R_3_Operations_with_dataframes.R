########################################################################################################################.
########################################################################################################################.
########################################################################################################################.
########                                                                                                        ########.
########           TRAINING ON STRATEGIES TO CALCULATE LFS SAMPLE WEIGHTS USING CALIBRATION                     ########.
########                                                                                                        ########.
########          PREPARED BY: ANTONIO R. DISCENZA - ILO DEPARTMENT OF STATISTICS - SSMU UNIT                   ########.
########                                    E.mail: discenza@ilo.org                                            ########.
########                                                                                                        ########.
########                             OPERATIONS WITH DATAFRAMES IN R                                            ########.
########                                                                                                        ########.
########################################################################################################################.
########################################################################################################################.


#############################################################################################################
###
###    READ DATA FROM A CSV FILE AND CREATE AN R DATAFRAME
###    help(read.csv)
###


### Assign the new path where wqe want to store the R objects and results

setwd("W:/ILO_LFS_GSBPM/DATA/Intro_to_R_and_ReGenesees/")
getwd()


###  Read the CSV file stored in the working directory 

population_figures <- read.csv(file="Population_2021_districts_sex_ur_ru_14agegroups.csv", na.strings= NA, quote="\"", dec= ".", strip.white= TRUE, comment.char= "")

###  Let's see the resulting R object 
population_figures 

###  show the first 6 lines of the dataframe 
head(population_figures)

###  View the dataframe in a separate window with grids
View(population_figures)

###  Let's see the dimensions of the resulting R object 
dim(population_figures)

###  Let's see the variables
ls(population_figures)

### Show the structure of the object (dataframe) 
str(population_figures)



##############################################################################################################
###  
###  LETS SELECTS ONE OR MORE VARIABLES, ALL RECORDS OR JUST A GROUP OF RECORDS
###  
###  example: population_figures[ (here we choose the rows) , (here we chose the columns)] 
###  

### gets the first 4 columns, all records  
red1 <- population_figures[   ,   c(1,2,3,4)] 
red1

### gets three specified variables, all records  
red2 <- population_figures[,c("region_descr","district_descr","sex_descr" )] 
red2

### gets four specified variables, only the records of "Region 1"  
red3 <- population_figures[population_figures$region_descr=="Region 1" ,
                           c("region_descr","district_descr","sex_descr","group_age_75_plus" )] 
red3

### gets four specified variables, only the records of "Region 1" and "Females"  
red4 <- population_figures[ population_figures$region_descr=="Region 1" & population_figures$sex_descr=="Females",  
                            c("region_descr","district_descr","sex_descr","group_age_75_plus" )] 
red4

### gets four specified variables, only the records of "Region 1" and "Females" using the "subset" function 

red5sub <- subset(population_figures, region_descr=="Region 1" & sex_descr=="Females", select = c("region_descr","district_descr","sex_descr","group_age_75_plus" ))
red5sub 



##############################################################################################################
###  
###  LETS RE-ORDER THE DATAFRAME
###

### Reorder using only one variable

population_figures <-  population_figures[order(population_figures$region_descr),]
View(population_figures)


### Reorder using four variable, all ascending
population_figures <-  population_figures[order(population_figures$region_descr,population_figures$district_descr,population_figures$urban_rural,-xtfrm(population_figures$sex_descr)),]
View(population_figures)

### Reorder using four variable, the first three ascending, last one descending (use a - for numeric and -xtfrm() for character )
population_figures <-  population_figures[order(population_figures$region_descr,population_figures$district_descr,population_figures$urban_rural,-xtfrm(population_figures$sex_descr)),]
View(population_figures)



##############################################################################################################
###  
###  ADDING COLUMNS DERIVED FROM A TRANSFORMATION OF EXISTING VARIABLES
### 

###  we want to create the variable REGION containing the code of the region (from 1 to 4)
###  we use a substring function to extract the code from the variable "region_descr" (the 8th character)


### check the number of characters
nchar_reg <- nchar(population_figures$region_descr)
nchar_reg

###  use a substring function with fixed parameters (when all the strings have the same length)
population_figures$REGION <- substr(population_figures$region_descr,8,8)
head(population_figures)

###  use a substring function with variable parameters (when the strings have different lengths)
population_figures$REGIONx <- substr(population_figures$region_descr,nchar_reg-0,nchar_reg)
population_figures

###  transform the variable region as factor (different levels) as required by the routines used later
population_figures$REGION <- as.factor(population_figures$REGION)

plot(population_figures$REGION )

plot(population_figures$REGIONx )

### Show the structure of the dataframe
str(population_figures)


##############################################################################################################
###  
###  SUMMARING INFORMATION FROM THE DATAFRAME
###  

### Compute summary statistics for all the variables
summary( population_figures )

### Compute summary statistics for selected variables
summary( population_figures[ , c("group_age_20_24","group_age_25_29") ] )

### Compute summary statistics for selected variables, only for "Region 1"
summary( population_figures[population_figures$region_descr=="Region 1" , c("group_age_20_24","group_age_25_29") ] )

### Compute summary statistics for selected variables, only for "Region 1" using the new variable region
summary( population_figures[population_figures$REGION=="1" , c("group_age_20_24","group_age_25_29") ] )

### Compute the sum of selected columns
colSums( population_figures[ , c("group_age_20_24","group_age_25_29") ] )

### Compute the sum of selected columns, only for "Region 1"
colSums( population_figures[population_figures$REGION=="1" , c("group_age_20_24","group_age_25_29") ] )


### Create the new variable "group_age_tot" with the sum of the 14 variables "group_age_"  for each row (to obtain the total population)
population_figures$group_age_tot <- rowSums( population_figures[, seq(7,20) ] )

head(population_figures)

### Check the total population over the different geographical domains
sum(population_figures$group_age_tot)


