########################################################################################################################.
########################################################################################################################.
########################################################################################################################.
########                                                                                                        ########.
########           TRAINING ON STRATEGIES TO CALCULATE LFS SAMPLE WEIGHTS USING CALIBRATION                     ########.
########                                                                                                        ########.
########          PREPARED BY: ANTONIO R. DISCENZA - ILO DEPARTMENT OF STATISTICS - SSMU UNIT                   ########.
########                                    E.mail: discenza@ilo.org                                            ########.
########                                                                                                        ########.
########                             PARAMETERIZATION OF PATHS AND SCRIPTS IN R                                 ########.
########                                                                                                        ########.
########################################################################################################################.
########################################################################################################################.

##############################################################################################################
###
###    PARAMETERIZE PATHS
###
###  Note that the "\" is not recognized by R, we need a "\\" instead 
###  or a more general "/" (recognized on all operating systems) 
###

library("haven")
###  Lets set the main root on our computer o server (where we have the LFS data and programs )

root_lfs <- "W:/ILO_LFS_GSBPM"
root_lfs

###  Set the path of the folder from which we want to read the csv file "560_POPULATION_ESTIMATES"

dir_data_550DV <- paste( root_lfs , "/DATA/550_DERIVED_VARIABLES/2021/Quarter1/" , sep='')
dir_data_550DV

###  Set the name of the csv file from which we want to read the data "POP_LFS_BY_REGION_SEX_12AGEGR_2021_Q1.csv"


FILE_LFS_ILO_DER_SAV <- paste( dir_data_550DV , "LFS_ILO_2021_Q1_DER.sav", sep='')
FILE_LFS_ILO_DER_SAV


###  Create the R Dataframe reading from the spss dataset

### instead of using the following

# LFS_ILO_DER <- read_sav("W:/2023_ILO_ITC_WEIGHTING/LFS_GSBPM_SW/DATA/550_DERIVED_VARIABLES/2021/Quarter1/LFS_ILO_2021_Q1_DER.sav")

### we can use this command

LFS_ILO_DER <- read_sav(FILE_LFS_ILO_DER_SAV)

View(LFS_ILO_DER)

table(LFS_ILO_DER$YEAR, LFS_ILO_DER$QUARTER)




#######################################################################################################################
###
###    It is much more convenient to parameterize the year and quarter so that we can reuse this scripts for another survey wave 
###
########################################################################################################################

########################################################################################################################
###
###   define the parameters for year and quarter
###

###   choose the year
year=2021
year 

###   choose the quarter
quarter=1
quarter 

###   the root of the lfs file strustrure does not depend on year and quarter


root_lfs <- "W:/ILO_LFS_GSBPM"
root_lfs


##############################################################################################################
###
###  Let's parameterize the path of the folder from which we want to read the csv file 
###

###  To learn how to do it, let's do it gradually. Firstly we divide the "fixed" and "variable" blocks of the path 
###  "LFS_GSBPM_SW/DATA/550_DERIVED_VARIABLES/2021/Quarter1/"

dir_data_550DV <- paste( root_lfs , "/DATA/550_DERIVED_VARIABLES/", 2021, "/Quarter", 1 , "/" , sep='')
dir_data_550DV

###  Then we substitute the variable blocks with the macro variables 

dir_data_550DV <- paste( root_lfs , "/DATA/550_DERIVED_VARIABLES/", year, "/Quarter", quarter , "/" , sep='')
dir_data_550DV




##############################################################################################################
###
###  Let's parameterize the name of the csv file from which we want to read the data 
###  LFS_ILO_2021_Q1_DER.sav
###

##  Again, let's do it gradually. Firstly we divide the "fixed" and "variable" blocks of the path (we can remove this once completed the next lines)

FILE_LFS_ILO_DER_SAV <- paste( dir_data_550DV , "LFS_ILO_", 2021 , "_Q" , 1 , "_DER.sav", sep='')
FILE_LFS_ILO_DER_SAV

##  Then we substitute the variable blocks with the macro variables 

FILE_LFS_ILO_DER_SAV <- paste( dir_data_550DV , "LFS_ILO_", year , "_Q" , quarter , "_DER.sav", sep='')
FILE_LFS_ILO_DER_SAV



###  Create the R Dataframe reading from the spss dataset

LFS_ILO_DER <- read_sav(FILE_LFS_ILO_DER_SAV)

table(LFS_ILO_DER$YEAR, LFS_ILO_DER$QUARTER)


###  Let's run the lines above for the second quarter 2021




##############################################################################################################
###
###  We can also parameterize the output folders and other files names 
###

###  Set the path of the folder in which we want to save the tables

dir_data_610DT <- paste( root_lfs , "/DATA/610_DRAFT_TABLES/", year , "/Quarter",  quarter ,"/" , sep='')
dir_data_610DT

###  Output xlsx file containing the excel table

FILE_TABLE_XLSX  <- paste( dir_data_610DT , "TABLE_1_LFS_", year ,"_Q", quarter ,".xlsx",sep='')
FILE_TABLE_XLSX



#############################################################################################################
###
###    PRODUCING PRE-FORMATTED WEIGHTED TABLES 
###
###    We could produce complex tables ready for publication in EXCEL using the following workflow
###
###    1 - Create the table in R and save it as dataframe
###    2 - Create the empty template in excel already formatted as needed for dissemination
###    3 - Export the numbers of the table from the R dataframe to the excel template
###    4 - Save the excel file with the desired name in the desired folder on disk

library("expss")


#############################################################################################################
###
###    STEP 1 - Create the table in R and save it as dataframe


#############################################################################################################
###    Create labels for the variables SEX, AGE_GROUP7 and ilo_lfs  

list_labels 	<- list( 
  REGION = "REGION",
  REGION = num_lab("1 1-Region1 
                    2 2-Region2 
                    3 3-Region3 
                    4 4-Region4"),
  
  SEX = "Sex",
  SEX = num_lab("1 1-Males 
                                     2 2-Females"),
  
  AGE_GROUP7 = "Age in 7 groups",
  AGE_GROUP7 = num_lab("1 1 - 0-14 
                                            2 2 - 15-24
                                            3 3 - 25-34
                                            4 4 - 35-44
                                            5 5 - 45-54
                                            6 6 - 55-64
                                            7 7 - 65+"),
  
  ilo_lfs = "Labour Status",
  ilo_lfs = num_lab("1 1-Employed 
                                         2 2-Unemployed 
                                         3 3-Outside Labour Force")
)


###    Apply label to the dataframe with the sample data and create a new temporary dataframe 
###    that will be used to prepare the tables

tmp_data_DER_withlab = apply_labels(LFS_ILO_DER, list_labels)

str(tmp_data_DER_withlab)

#############################################################################################################
###  create the table

tmp_TABLE_1 <-
  tmp_data_DER_withlab %>%
  tab_cols(  list(SEX,total(label="Males and Females"))    %nest%  list(ilo_lfs ,total(label="Total Population"))  )  %>%
  tab_rows(      list(REGION,total(label="Total Country"))    %nest%    list(AGE_GROUP7,total(label="Total Age Groups"))  ) %>%
  tab_weight(DESIGN_WEIGHT) %>%
  tab_stat_sum () %>%
  tab_pivot() %>%
  as.data.frame()

View(tmp_TABLE_1)

#############################################################################################################
###
###    STEP 2 - Create the empty template in excel already formatted as needed for dissemination

###    Check the empty template in the folder "LFS_GSBPM_SW\PROG\Intro_to_R_and_ReGenesees"



#############################################################################################################
###
###    STEP 3 - Export the numbers of the table from the R dataframe to the excel template
###             using the package "excel.link"

library(excel.link)

#############################################      OPEN EXCEL      #####################

xls = xl.get.excel()


#############################################      CLOSE THE DEFAULT SHEET #####################

xl.workbook.close(xl.workbook.name = NULL)



############################    OPEN THE EMPTY TEMPLATE ALREADY FORMATTED  #####################

xl.workbook.open( "W:/ILO_LFS_GSBPM/PROG/Intro_to_R_and_ReGenesees/Template_table_1.xlsx" )



######################      SET THE FIRST CELLS OF THE EMPTY TEMPLATE WHERE THE DATA WILL BE SAVED       #####################

firstcelldata = xls[["Activesheet"]]$Cells(5,4)



######################  WRITE DATA (NOT LABEL) TO THE RENAMED EMPTY TEMPLATE READING FROM THE DATAFRAME CONTAINTING THE R TABLE #####################

xl.write(as.data.frame(tmp_TABLE_1)[,seq(2,13)], firstcelldata, row.names = FALSE,col.names = FALSE)



######################    WRITE THE REFERENCE PERIOD IN THE TABLE OF THE TABLE     #####################

### Define the cell where to write the reference period

celltitle = xls[["Activesheet"]]$Cells(1,9)

### Write the reference period

xl.write(paste(year ,"_Q", quarter ,sep=''), celltitle)


#############################################################################################################
###
###    STEP 4 - Save the excel file with the desired name in the desired folder on disk

####################     SAVE WITH ANOTHER NAME IN A SPECIFIC FOLDER (CAN BE PARAMETERISED)     #####################

xl.workbook.save(FILE_TABLE_XLSX)



######################     CLOSE THE EXCEL TABLE  #####################

xl.workbook.close(xl.workbook.name = NULL)


