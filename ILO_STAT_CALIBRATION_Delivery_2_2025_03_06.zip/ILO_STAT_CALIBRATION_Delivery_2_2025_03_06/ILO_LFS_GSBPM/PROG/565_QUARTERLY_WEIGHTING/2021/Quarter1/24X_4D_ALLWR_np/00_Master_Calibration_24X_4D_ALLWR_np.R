########################################################################################################################.
########################################################################################################################.
########################################################################################################################.
########                                                                                                        ########.
########           TRAINING ON STRATEGIES TO CALCULATE LFS SAMPLE WEIGHTS USING CALIBRATION                     ########.
########                                                                                                        ########.
########          PREPARED BY: ANTONIO R. DISCENZA - ILO DEPARTMENT OF STATISTICS - SSMU UNIT                   ########.
########                                    E.mail: discenza@ilo.org                                            ########.
########                                                                                                        ########.
########                                 CASE STUDY N. 3 - (24X_4D_ALLWR_np)                                    ########.
########                       CALIBRATION OF FINAL WEIGHTS USING R FOR ALL STEPS ( suffix _ALLWR)              ########.
########                                                                                                        ########.
########                                    BASED ON THE R PACKAGE "REGENESSES"                                 ########.
########                               see https://diegozardetto.github.io/ReGenesees/                          ########.
########                                                                                                        ########.
########                      Version A:  Filenames and paths are not parameterized ( suffix _np)               ########.
########                                                                                                        ########.
########                                                                                                        ########.
########                                        MASTER SCRIPT                                                   ########.
########                                                                                                        ########.
########                                                                                                        ########.
########    Population figures available from an external trusted official source to be used as benchmarks      ########.  
########    for the final weights are stored in the following folder                                            ########.  
########    "W:/ILO_LFS_GSBPM/DATA/560_POPULATION_ESTIMATE/2021/Quarter1/                                       ########.
########                                                                                                        ########.
########    Microdata containing the interviews successfully completed are stored in the following folder       ########.  
########    "W:/ILO_LFS_GSBPM/DATA/550_DERIVED_VARIABLES/2021/Quarter1/                                         ########.
########    These microdata have been edited and imputed and contain the theorethical design weights.           ########.  
########    Final weights will be calculated starting from design weights using Regenesees and will be attached ########.
########    back to the microdata file                                                                          ########.
########                                                                                                        ########.
########    The folder containing the sequence of R scripts needed for the procedure is                         ########.
########    "W:/ILO_LFS_GSBPM/PROG/565_QUARTERLY_WEIGHTING/2021/Quarter1/24X_4D_ALLWR_np/                       ########.
########                                                                                                        ########.
########    The outputs of the procedure (both R objects and Excel files) will be stored in the folder          ########.
########    "W:/ILO_LFS_GSBPM/DATA/565_QUARTERLY_WEIGHTING/2021/Quarter1/24X_4D_ALLWR_np/                       ########.                                                                                           ###
########    Please create such folder in your file structure before starting                                    ########.
########                                                                                                        ########.
########    The set of R scripts connected to this master script relates to Quarter 1 2021.                     ########.
########                                                                                                        ########.
########    To reuse these scripts in another quarter do the following:                                         ########.
########         a) make a copy of all scripts in the folder of a new quarter;                                  ########.
########         b) substitute the two strings "/2021/Quarter1/ " and "2021_Q1" accordingly                     ########.
########                                                                                                        ########.
########    To reuse these scripts with another set of constraints:                                             ########.
########         a) make a copy of all scripts in another folder and rename accordingly;                        ########.
########         b) substitute the string "24X_4D" accordingly (e.g. 66X_4D") within paths and filenames;       ########.
########         c) modify the scripts to include the new constraints                                           ########.
########                                                                                                        ########.
########################################################################################################################.
########################################################################################################################.
########################################################################################################################.


###  Lets first remove all the objects from the memory of the current session

rm(list = ls())
ls()

#######   INSTALL PACKAGES  ##################################################################################
###
###    THE PACKAGES BELOW HAVE TO BE INSTALLED ONLY ONCE. THEN THE CODE CAN BE COMMENTED USING THE HASHTAG  
###
##############################################################################################################

### To install Regenesees 
# install.packages("devtools")
# devtools::install_github("DiegoZardetto/ReGenesees")

### or also  
# install.packages("remotes")
# remotes::install_github("DiegoZardetto/ReGenesees")
# remotes::install_github("DiegoZardetto/ReGenesees.GUI")


### To install all the other packages
# remotes::install_github("dcomtois/summarytools")
# install.packages("summarytools")

# install.packages("dplyr")
# install.packages("excel.link")
# install.packages("writexl")

### install the library to create multidimensional tables with weighted data 
# install.packages("expss")

### install the library to read and write SPSS and STATA datasets 
# install.packages("haven")



#######   ACTIVATE PACKAGES   #################################################################################
###
###    Activate the libraries that are needed by the procedure every time need to design a sample
###
##############################################################################################################

library("ReGenesees")     # to calculate weights, CVs and DEFFs
library("dplyr")          # to summarize data
library("summarytools")   # to summarize data
library("excel.link")     # contains the functions xl.get.excel(), xl.write(), xl.workbook.save()
library("readxl")         # to export R dataframes in excel
library("writexl")        # to export R dataframes in excel
library("expss")          # contains functions to create weighted tables
library("haven")          # to read and write SPSS and STATA datasets 



##############################################################################################################
###
###    RUN THE SEQUENCE OF SCRIPTS BELOW TO COMPLETE CALIBRATION OF FINAL WEIGHTS           
###
##############################################################################################################

### The sequence of scripts is stored in the following folder 
### "W:/ILO_LFS_GSBPM/PROG/565_QUARTERLY_WEIGHTING/2021/Quarter1/24X_4D_ALLWR_np/ 




#######   RUN SCRIPT 01   ###########################################################################################
###
###    Read in R the full sample data and population figures available in the CSV format stored in a specific directory
###
##############################################################################################################

### run the script below step by step (in the prog folder) and check the outputs (in the data folder)

# "01_Upload_Sample_Data_and_Known_Totals_in_R_2021_Q1.R"



#######   UPDATE EXCEL SCHEME ON SET OF CONSTRAINTS  #########################################################
###
###    Update excel scheme an programs to format summary tables on calibration produced by Regenesees
###
##############################################################################################################

# "01_Set_of_constraints_24X_4D.xlsx"


#######   RUN SCRIPT 02   ###########################################################################################
###
###       PREPARE INPUT SAMPLE DATA FOR REGENESEES 
###
##############################################################################################################

### run the script below step by step (in the prog folder) and check the outputs (in the data folder)

# "02_Prepare_input_sample_data_for_regenesees_2021_Q1_24X_4D_ALLWR_np.R"



#######   RUN SCRIPT 3   ###########################################################################################
###
###       PREPARE KNOWN TOTALS DATA FOR REGENESEES 
###
##############################################################################################################

### run the script below step by step (in the prog folder) and check the outputs (in the data folder)

# "03_Prepare_input_pop_figures_for_regenesees_2021_Q1_24X_4D_ALLWR_np.R"




#######   RUN SCRIPT 04c   ###########################################################################################
###
###       RUN CALIBRATION WITH REGENESEES 
###
##############################################################################################################

### run the script below step by step (in the prog folder) and check the outputs (in the data folder)

# "04c_Run_Quarterly_Calibration_with_Regenesees_24X_4D_ALLWR_np.R"



#######   RUN SCRIPT 5   ###########################################################################################
###
###       ATTACH FINAL WEIGHTS TO THE DATASET CONTAINING THE FULL SAMPLE DATA  
###
##############################################################################################################

### run the script below step by step (in the prog folder) and check the outputs (in the data folder)

# "05_Attach_final_weights_to_full_sample_data_2021_Q1_24X_4D_ALLWR_np"



#######   RUN SCRIPT 6   ###########################################################################################
###
###       CHECK ESTIMATES OBTAINED WITH FINAL WEIGHTS 
###
##############################################################################################################

### run the script below step by step (in the prog folder) and check the outputs (in the data folder)

# "06_Create_Table1_2021_Q1_24X_4D_ALLWR_np"

