########################################################################################################################.
########################################################################################################################.
########################################################################################################################.
########                                                                                                        ########.
########           TRAINING ON STRATEGIES TO CALCULATE LFS SAMPLE WEIGHTS USING CALIBRATION                     ########.
########                                                                                                        ########.
########          PREPARED BY: ANTONIO R. DISCENZA - ILO DEPARTMENT OF STATISTICS - SSMU UNIT                   ########.
########                                    E.mail: discenza@ilo.org                                            ########.
########                                                                                                        ########.
########                                 CASE STUDY N. 3 - (24X_4D_ALLWR_np)                                    ########.
########                       CALIBRATION OF FINAL WEIGHTS USING R FOR ALL STEPS                               ########.
########                                                                                                        ########.
########                      Version A:  Filenames and paths are not parameterized                             ########.
########                                                                                                        ########.
########                                                                                                        ########.
########                                        R Script 02                                                     ########.
########                                                                                                        ########.
########        PROGRAM TO PREPARE INPUT SAMPLE DATA FOR FINAL CALIBRATION USING REGENESEES                     ########.
########                                                                                                        ########.
########        4 DOMAINS  (4 Regions)                                                                          ########.
########        24 CONSTRAINTS (X1 TO X24)                                                                      ########.
########              - Population by region, sex and 12 age groups    (X1 TO X24)                              ########.
########                                                                                                        ########.
########################################################################################################################.
########################################################################################################################.

######################################################################################################
###  
###   STEP 2.1 - SET THE WORKING DIRECTORY WHERE THE OUPUTS OF THE CALIBRATION PROCESS WILL BE STORED 
### 
######################################################################################################

setwd("W:/ILO_LFS_GSBPM/DATA/565_QUARTERLY_WEIGHTING/2021/Quarter1/24X_4D_ALLWR_np/")
getwd()


######################################################################################################
###  
###   STEP 2.2 - LOAD THE INPUT DATAFRAME CONTAINING THE SAMPLE DATA FROM FOLDER 550  
### 
######################################################################################################

ls()

# rm(LFS_ILO_DER)

load(file="W:/ILO_LFS_GSBPM/DATA/550_DERIVED_VARIABLES/2021/Quarter1/LFS_ILO_2021_Q1_DER.RData")

ls()


### check its the structure

str(LFS_ILO_DER)


### Create a new dataframe that will be renamed at the end of the steps as LFS_SAMPLE_DATA_2021_Q1_24X_4D_ALLWR_np
### Working on the new dataframe will help to avoid possible unwanted modifications/errors on the original dataset.
### The shorter name will help when we have to write the code. The prefix tmp will help to recognize that is a temporary
### dataframe that does not need to be saved permanently on disk  

tmpSD <- LFS_ILO_DER

head(tmpSD)



######################################################################################################
###  
###   STEP 2.3 - CALCULATE THE SET OF 24 X VARIABLES (DUMMY 0,1)  
### 
######################################################################################################


###   Create the X variables and initialize them to 0

tmpSD$X1 <- 0 
tmpSD$X2 <- 0 
tmpSD$X3 <- 0 
tmpSD$X4 <- 0 
tmpSD$X5 <- 0 
tmpSD$X6 <- 0 
tmpSD$X7 <- 0 
tmpSD$X8 <- 0 
tmpSD$X9 <- 0 
tmpSD$X10 <- 0 
tmpSD$X11 <- 0 
tmpSD$X12 <- 0 
tmpSD$X13 <- 0 
tmpSD$X14 <- 0 
tmpSD$X15 <- 0 
tmpSD$X16 <- 0 
tmpSD$X17 <- 0 
tmpSD$X18 <- 0 
tmpSD$X19 <- 0 
tmpSD$X20 <- 0 
tmpSD$X21 <- 0 
tmpSD$X22 <- 0 
tmpSD$X23 <- 0 
tmpSD$X24 <- 0 


###    For each record of the dataset, the following code will assign 1 to the X variables based on the specific conditions  

tmpSD$X1[ tmpSD$AGE>=  0 & tmpSD$AGE <=14 & tmpSD$SEX==1] <- 1
tmpSD$X2[ tmpSD$AGE>= 15 & tmpSD$AGE <=19 & tmpSD$SEX==1] <- 1
tmpSD$X3[ tmpSD$AGE>= 20 & tmpSD$AGE <=24 & tmpSD$SEX==1] <- 1
tmpSD$X4[ tmpSD$AGE>= 25 & tmpSD$AGE <=29 & tmpSD$SEX==1] <- 1
tmpSD$X5[ tmpSD$AGE>= 30 & tmpSD$AGE <=34 & tmpSD$SEX==1] <- 1
tmpSD$X6[ tmpSD$AGE>= 35 & tmpSD$AGE <=39 & tmpSD$SEX==1] <- 1
tmpSD$X7[ tmpSD$AGE>= 40 & tmpSD$AGE <=44 & tmpSD$SEX==1] <- 1
tmpSD$X8[ tmpSD$AGE>= 45 & tmpSD$AGE <=49 & tmpSD$SEX==1] <- 1
tmpSD$X9[ tmpSD$AGE>= 50 & tmpSD$AGE <=54 & tmpSD$SEX==1] <- 1
tmpSD$X10[tmpSD$AGE>= 55 & tmpSD$AGE <=59 & tmpSD$SEX==1] <- 1
tmpSD$X11[tmpSD$AGE>= 60 & tmpSD$AGE <=64 & tmpSD$SEX==1] <- 1
tmpSD$X12[tmpSD$AGE>= 65                  & tmpSD$SEX==1] <- 1

tmpSD$X13[tmpSD$AGE>=  0 & tmpSD$AGE <=14 & tmpSD$SEX==2] <- 1
tmpSD$X14[tmpSD$AGE>= 15 & tmpSD$AGE <=19 & tmpSD$SEX==2] <- 1
tmpSD$X15[tmpSD$AGE>= 20 & tmpSD$AGE <=24 & tmpSD$SEX==2] <- 1
tmpSD$X16[tmpSD$AGE>= 25 & tmpSD$AGE <=29 & tmpSD$SEX==2] <- 1
tmpSD$X17[tmpSD$AGE>= 30 & tmpSD$AGE <=34 & tmpSD$SEX==2] <- 1
tmpSD$X18[tmpSD$AGE>= 35 & tmpSD$AGE <=39 & tmpSD$SEX==2] <- 1
tmpSD$X19[tmpSD$AGE>= 40 & tmpSD$AGE <=44 & tmpSD$SEX==2] <- 1
tmpSD$X20[tmpSD$AGE>= 45 & tmpSD$AGE <=49 & tmpSD$SEX==2] <- 1
tmpSD$X21[tmpSD$AGE>= 50 & tmpSD$AGE <=54 & tmpSD$SEX==2] <- 1
tmpSD$X22[tmpSD$AGE>= 55 & tmpSD$AGE <=59 & tmpSD$SEX==2] <- 1
tmpSD$X23[tmpSD$AGE>= 60 & tmpSD$AGE <=64 & tmpSD$SEX==2] <- 1
tmpSD$X24[tmpSD$AGE>= 65                  & tmpSD$SEX==2] <- 1


######################################################################################################
###  
###   STEP 2.4 - CREATE THE VARIABLE "DOMAIN" THAT IDENTIFIES THE DOMAIN OF ESTIMATION   
### 
######################################################################################################

tmpSD$DOMAIN <- as.character(tmpSD$REGION)


######################################################################################################
###  
###   STEP 2.5 - CREATE THE DUMMY VARIABLES NEEDED TO CALCULATE THE MAIN LFS INDICATORS AND THEIR PRECISION  
### 
######################################################################################################


###   Respondents in working age 15 plus   

tmpSD$POP_15plus <- 0
tmpSD$POP_15plus[tmpSD$AGE>=15] <- 1


###   Respondents in Labour Force

tmpSD$LF_15plus <- 0
tmpSD$LF_15plus[tmpSD$AGE>=15 & (tmpSD$ilo_lfs==1 | tmpSD$ilo_lfs==2 ) ] <- 1

tmpSD$LF_15plus_100 <- tmpSD$LF_15plus * 100 

###   Respondents in Employment

tmpSD$EMP_15plus <- 0
tmpSD$EMP_15plus[tmpSD$AGE>=15 & tmpSD$ilo_lfs==1 ] <- 1

tmpSD$EMP_15plus_100 <- tmpSD$EMP_15plus * 100 

###   Respondents in Unemployment

tmpSD$UNE_15plus <- 0
tmpSD$UNE_15plus[tmpSD$AGE>=15 & tmpSD$ilo_lfs==2 ] <- 1

tmpSD$UNE_15plus_100 <- tmpSD$UNE_15plus * 100 

names(tmpSD)


######################################################################################################
###  
###   STEP 2.6 - CREATE AN OBJECT CONTAING THE LIST OF Xs TO RETAIN TO BE USED IN THE NEXT STEPS  
### 
######################################################################################################


###   We can use the following code 

list_of_X <- c("X1","X2","X3","X4","X5","X6","X7","X8","X9","X10","X11","X12","X13","X14","X15","X16","X17","X18","X19","X20","X21","X22","X23","X24")  
list_of_X 


###   or alternatively the next one (much more useful when we have a huge number of X)

list_of_X  <- paste(rep("X",24),seq(1,24),sep="")
list_of_X 


######################################################################################################
###  
###   STEP 2.7 - CREATE THE R DATAFRAME WITH THE SAMPLE DATA THAT ARE USED AS FIRST INPUT BY REGENESEES  
### 
######################################################################################################


### We can create the R dataframe with the sample data 
### keeping only the variables needed for weighting and to calculate Precision

LFS_SAMPLE_DATA <- tmpSD[,c("YEAR", "QUARTER", "MONTH", "REGION", "DISTRICT", "UR_RU", "DOMAIN", "STRATAKEY", "PSUKEY", "HHKEY", "INDKEY", 
                            "SEX", "AGE", "AGE_GROUP7", "AGE_GROUP12", 
                            list_of_X, 
                            "POP_15plus", "LF_15plus", "LF_15plus_100", "EMP_15plus", "EMP_15plus_100", "UNE_15plus", "UNE_15plus_100", "DESIGN_WEIGHT")]

head( LFS_SAMPLE_DATA)


### We can remove the temporary dataframe 
ls()
rm(tmpSD)
ls()


######################################################################################################
###  
###   STEP 2.8 - SAVE ON DISK THE R DATAFRAME WITH THE SAMPLE DATA IN THE OUTPUT FOLDER   
### 
######################################################################################################


### If we have set the working directory for the outputs we can use 

save(LFS_SAMPLE_DATA, file="LFS_SAMPLE_DATA_2021_Q1_24X_4D_ALLWR_np.RData")


### If we have not set the working directory for the outputs (or we need to save the object in a different folder) we can use 

# save(LFS_SAMPLE_DATA ,file='W:/ILO_LFS_GSBPM/DATA/565_QUARTERLY_WEIGHTING/2021/Quarter1/24X_4D_ALLWR_np/LFS_SAMPLE_DATA_2021_Q1_24X_4D_ALLWR_np.RData')



######################################################################################################
###  
###   STEP 2.9 - CHECK THE POPULATION ESTIMATES OBTAINED USING THE DESIGN WEIGHT   
### 
######################################################################################################


### Create a table using the package "expss" 
### and the magritte %>% pipe operators (see https://magrittr.tidyverse.org/reference/pipe.html)

LFS_SAMPLE_DATA  %>%
  tab_cols(SEX, total()) %>%
  tab_rows(DOMAIN, total()) %>%
  tab_weight(DESIGN_WEIGHT) %>%
  tab_stat_sum %>%
  tab_pivot()


######################################################################################################
###  
###   STEP 2.10 - SUMMARIZE BY DOMAIN TO SAVE IN A DATAFRAME THE SAMPLE SIZE FOR EACH X
###  
######################################################################################################


### Create a table (stored in the R object "LFS_SAMPLE_DATA_SUMMARY_OF_Xs_SAMPLE_SIZE" ).

LFS_SAMPLE_DATA_SUMMARY_OF_Xs_SAMPLE_SIZE <- aggregate( x = LFS_SAMPLE_DATA[, list_of_X], 
                                                       by = list(DOMAIN = LFS_SAMPLE_DATA$DOMAIN), 
													  FUN = sum)

View(LFS_SAMPLE_DATA_SUMMARY_OF_Xs_SAMPLE_SIZE)


###   Save permanently the object in the destination folder  
###   If we have set the working directory for the outputs we can use 

save(LFS_SAMPLE_DATA_SUMMARY_OF_Xs_SAMPLE_SIZE, file="LFS_SAMPLE_DATA_2021_Q1_24X_4D_ALLWR_np_SUMMARY_OF_Xs_SAMPLE_SIZE.RData")


###   Save the results in an excel file using the package "writexl"

write_xlsx(LFS_SAMPLE_DATA_SUMMARY_OF_Xs_SAMPLE_SIZE,
          "LFS_SAMPLE_DATA_2021_Q1_24X_4D_ALLWR_np_SUMMARY_OF_Xs_SAMPLE_SIZE.xlsx" )



######################################################################################################
###  
###   STEP 2.11 - SUMMARIZE BY DOMAIN TO SAVE IN A DATAFRAME THE ESTIMATES OBTAINED USING THE DESIGN WEIGHT
###  
######################################################################################################


### Create a table (stored in the object "LFS_SAMPLE_DATA_2021_Q1_24X_4D_ALLWR_np_SUMMARY_OF_Xs_EST_DES_WEIGHT" ). 
### Now, we need to weight the X

LFS_SAMPLE_DATA_SUMMARY_OF_Xs_EST_DES_WEIGHT <-
  LFS_SAMPLE_DATA  %>%
  tab_cols(mdset(X1 %to% X24),total()) %>%
  tab_rows(DOMAIN, total()) %>%
  tab_weight(DESIGN_WEIGHT) %>%
  tab_stat_sum %>%
  tab_pivot() %>%
  as.data.frame()

View(LFS_SAMPLE_DATA_SUMMARY_OF_Xs_EST_DES_WEIGHT)


###   Save permanently the object in the destination folder  
###   If we have set the working directory for the outputs we can use 

save(LFS_SAMPLE_DATA_SUMMARY_OF_Xs_EST_DES_WEIGHT, file="LFS_SAMPLE_DATA_2021_Q1_24X_4D_ALLWR_np_SUMMARY_OF_Xs_EST_DES_WEIGHT.RData")


###   Save the results in an excel file

write_xlsx(LFS_SAMPLE_DATA_SUMMARY_OF_Xs_EST_DES_WEIGHT,
          "LFS_SAMPLE_DATA_2021_Q1_24X_4D_ALLWR_np_SUMMARY_OF_Xs_EST_DES_WEIGHT.xlsx" )


