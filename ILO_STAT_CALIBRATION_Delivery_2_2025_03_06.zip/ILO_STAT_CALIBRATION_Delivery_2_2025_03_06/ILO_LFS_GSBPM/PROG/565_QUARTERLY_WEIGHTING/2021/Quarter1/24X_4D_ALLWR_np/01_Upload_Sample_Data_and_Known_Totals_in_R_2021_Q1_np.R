########################################################################################################################.
########################################################################################################################.
########################################################################################################################.
########                                                                                                        ########.
########           TRAINING ON STRATEGIES TO CALCULATE LFS SAMPLE WEIGHTS USING CALIBRATION                     ########.
########                                                                                                        ########.
########          PREPARED BY: ANTONIO R. DISCENZA - ILO DEPARTMENT OF STATISTICS - SSMU UNIT                   ########.
########                                    E.mail: discenza@ilo.org                                            ########.
########                                                                                                        ########.
########                                 CASE STUDY N. 3 - (24X_4D_ALLWR_np)                                    ########.
########                       CALIBRATION OF FINAL WEIGHTS USING R FOR ALL STEPS                               ########.
########                                                                                                        ########.
########                      Version A:  Filenames and paths are not parameterized                             ########.
########                                                                                                        ########.
########                                                                                                        ########.
########                                        R Script 01                                                     ########.
########                                                                                                        ########.
########      CREATE THE R DATAFRAMES CONTAINING                                                                ########.
########      - THE FULL SAMPLE DATA   (steps 1.1 and 1.2)                                                      ########.
########      - POPULATION FIGURES     (steps 1.3 and 1.4)                                                      ########.
########                                                                                                        ########.
########################################################################################################################.
########################################################################################################################.
########################################################################################################################.


######################################################################################################
###  
###   STEP 1.1 
### 
###   Read the full sample data available in the CSV format stored in a specific directory
### 
######################################################################################################

LFS_ILO_DER <- read.csv(file = "W:/ILO_LFS_GSBPM/DATA/550_DERIVED_VARIABLES/2021/Quarter1/LFS_ILO_2021_Q1_DER.csv" , numerals="no.loss", header= TRUE, sep= ",", na.strings= NA, quote="\"", dec= ".", strip.white= TRUE, comment.char= "")

###  show the first 6 lines of the dataset 

head(LFS_ILO_DER)

### See the structure of the object

str(LFS_ILO_DER)

View(LFS_ILO_DER)


### We have 53619 observations (individual interviews successfully completed) and 40 variables

### Note that the number of individuals interviewed can be obtained in different ways, and the result must be consistent

### For example, the number of individuals can be obtained summing the column of ones "POP_0plus", i.e.
### the dummy variable that identifies the population of age 0 plus (is 1 for all individuals interviewed) 

sum(LFS_ILO_DER$POP_0plus)

sum(LFS_ILO_DER$ilo_wap, na.rm=TRUE)

### and must also correspond to the number of records/rows of the dataframe

dim(LFS_ILO_DER)

### Individuals in the frame must have a unique identification code (INDKEY) hence let's verify it using the following instruction

length(unique(LFS_ILO_DER$INDKEY))

### We can also check how many households we have interviewed by counting the unique households ids (HHKEY)

length(unique(LFS_ILO_DER$HHKEY))

### and the number of enumeration areas (PSUKEY)

length(unique(LFS_ILO_DER$PSUKEY))

### We can also check how many households we have succesfully interviewed on average in each PSU
### dividing the numebr of households by the number of PSU

length(unique(LFS_ILO_DER$HHKEY)) / length(unique(LFS_ILO_DER$PSUKEY))

### The number of strata (STRATAKEY)

length(unique(LFS_ILO_DER$STRATAKEY))

### The number of districts (DISTRICT )

length(unique(LFS_ILO_DER$DISTRICT ))

### The number of regions (REGION)

length(unique(LFS_ILO_DER$REGION))



### We can also tabulate the actual sample size in several ways, for example using the function "table"

### to open the manual of the function table 

# help(table) 

table(LFS_ILO_DER$REGION)

table(LFS_ILO_DER$QUARTER, LFS_ILO_DER$MONTH )

table(LFS_ILO_DER$AGE_GROUP14, LFS_ILO_DER$SEX )

table(LFS_ILO_DER$SEX, LFS_ILO_DER$ilo_lfs)


### We can also check the estimates obtained using the design weights
### Create a table using the "expss" package and the magritte %>% pipe 
### (see https://magrittr.tidyverse.org/reference/pipe.html)

LFS_ILO_DER %>%
  tab_cols(SEX, total()) %>%
  tab_rows(REGION, total()) %>%
  tab_weight(DESIGN_WEIGHT) %>%
  tab_stat_sum %>%
  tab_pivot()


######################################################################################################
###  
###    STEP 1.2 
###
###    Save the R objects in the specific "DER" folder for future use
### 
######################################################################################################

save(LFS_ILO_DER ,file="W:/ILO_LFS_GSBPM/DATA/550_DERIVED_VARIABLES/2021/Quarter1/LFS_ILO_2021_Q1_DER.RData")

###  Check now within destination folder. We now have a new file named "LFS_SW_2021_Q1_DER.RData"


#######   NOTE   ###########################################################################################
###
###  When we want to reuse the R objects (.RData) in a future session we can use the following code. 

ls()

###  Lets first remove all the objects from the memory of the current session

rm(LFS_ILO_DER)
ls()


###  Load the object "LFS_ILO_2021_Q1_DER.RData" from the related folder

load(file="W:/ILO_LFS_GSBPM/DATA/550_DERIVED_VARIABLES/2021/Quarter1/LFS_ILO_2021_Q1_DER.RData")

###  Now check that the object "LFS_ILO_2021_Q1_DER" does exist. In R the object name is without ".Rdata"

ls()


###  Now let's verify again the content of the object

str(LFS_ILO_DER)






######################################################################################################
###  
###   STEP 1.3 
### 
###   Read the population figures available in the CSV format stored in a specific directory
### 
######################################################################################################


###  Read the CSV file stored in a specific directory 

POP_LFS_BY_REGION_SEX_12AGEGR <- read.csv(file = "W:/ILO_LFS_GSBPM/DATA/560_POPULATION_ESTIMATES/2021/Quarter1/POP_LFS_BY_REGION_SEX_12AGEGR_2021_Q1.csv" , numerals="no.loss", header= TRUE, sep= ",", na.strings= NA, quote="\"", dec= ".", strip.white= TRUE, comment.char= "")
POP_LFS_BY_REGION_SEX_12AGEGR

# View(POP_LFS_BY_REGION_SEX_12AGEGR)


######################################################################################################
###  
###    STEP 1.4 
###
###    Save the R objects in the specific folder for future use
### 
######################################################################################################

save(POP_LFS_BY_REGION_SEX_12AGEGR,file="W:/ILO_LFS_GSBPM/DATA/560_POPULATION_ESTIMATES/2021/Quarter1/POP_LFS_BY_REGION_SEX_12AGEGR_2021_Q1.RData")

###  Check now within destination folder. We now have a new file named "POP_LFS_BY_REGION_SEX_12AGEGR_2021_Q1.RData"


###  Check the R objects created

ls()




