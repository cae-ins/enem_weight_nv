########################################################################################################################.
########################################################################################################################.
########################################################################################################################.
########                                                                                                        ########.
########           TRAINING ON STRATEGIES TO CALCULATE LFS SAMPLE WEIGHTS USING CALIBRATION                     ########.
########                                                                                                        ########.
########          PREPARED BY: ANTONIO R. DISCENZA - ILO DEPARTMENT OF STATISTICS - SSMU UNIT                   ########.
########                                    E.mail: discenza@ilo.org                                            ########.
########                                                                                                        ########.
########                                 CASE STUDY N. 3 - (24X_4D_ALLWR_np)                                    ########.
########                       CALIBRATION OF FINAL WEIGHTS USING R FOR ALL STEPS                               ########.
########                                                                                                        ########.
########                      Version A:  Filenames and paths are not parameterized                             ########.
########                                                                                                        ########.
########                                                                                                        ########.
########                                        R Script 05                                                     ########.
########                                                                                                        ########.
########                         PROGRAM TO ATTACH FINAL WEIGHTS AND CORRECTION FACTORS                         ########.
########                          TO THE FULL SAMPLE "DER" TO CREATE THE DATASET "CAL"                          ########.
########                                                                                                        ########.
########        4 DOMAINS  (4 Regions)                                                                          ########.
########        24 CONSTRAINTS (X1 TO X24)                                                                      ########.
########              - Population by region, sex and 12 age groups    (X1 TO X24)                              ########.
########                                                                                                        ########.
########################################################################################################################.
########################################################################################################################.


######################################################################################################
###  
###   STEP 5.1 
###  
###   SET THE WORKING DIRECTORY WHERE THE OUPUTS WILL BE STORED 
### 
######################################################################################################


setwd("W:/ILO_LFS_GSBPM/DATA/565_QUARTERLY_WEIGHTING/2021/Quarter1/24X_4D_ALLWR_np/")
getwd()


######################################################################################################
###  
###   STEP 5.2 
###  
###   Load the R objects from the specific folder (not necessary if we have produced them in the same R session)  
###
##############################################################################################################

### Load the full sample dataframe "DER"

load(file='W:/ILO_LFS_GSBPM/DATA/550_DERIVED_VARIABLES/2021/Quarter1/LFS_ILO_2021_Q1_DER.RData')

head(LFS_ILO_DER)


### Load the dataframe with the final weights

load("LFS_CALIBRATION_2021_Q1_24X_4D_ALLWR_np_FINAL_WEIGHTS.RData")

head(LFS_CALIBRATION_FINAL_WEIGHTS )


######################################################################################################
###  
###   STEP 5.3 
###  
###   Merge the final weights to the full sample "DER" and create the new dataframe "CAL"  
###
##############################################################################################################


### select the variables to be merged with the full sample

tmp_FINAL_WEIGHTS <- LFS_CALIBRATION_FINAL_WEIGHTS[, c("INDKEY", "FINAL_CORR_FACTOR", "FINAL_WEIGHT")]

head(tmp_FINAL_WEIGHTS) 


### verify the dimension of the two dataframes (must have the same number of rows) 

dim(LFS_ILO_DER)

dim(tmp_FINAL_WEIGHTS)


### merge the two datasets by "INDKEY" (the unique identifiers of the individual respondents) 

LFS_ILO_CAL <- merge( LFS_ILO_DER, tmp_FINAL_WEIGHTS, by = "INDKEY") 


### verify the content and the dimension of the resulting "CAL" dataframe 

dim(LFS_ILO_CAL)

str(LFS_ILO_CAL)


######################################################################################################
###  
###   STEP 5.4 
###  
###   SAVE THE R DATAFRAME WITH THE FINAL WEIGHTS ON DISK   
###
##############################################################################################################

save(LFS_ILO_CAL, file="LFS_ILO_2021_Q1_CAL.RData")


######################################################################################################
###  
###   STEP 5.5 
###  
###    SAVE AN IMAGE OF ALL THE R OBJECTS CREATED IN THIS PHASE (CAN BE REUSED LATER FOR OTHER TASKS)
###
##############################################################################################################

ls()

save.image("LFS_CALIBRATION_2021_Q1_24X_4D_ALLWR_np_IMAGE.RData")

# load("LFS_CALIBRATION_2021_Q1_24X_4D_ALLWR_np_IMAGE.RData")


######################################################################################################
###  
###   STEP 5.6 
###  
###   CHECK FINAL ESTIMATES   
###
##############################################################################################################



### We can compare the estimates obtained using the design weights and final weights
### Create a table using the "expss" package and the magritte %>% pipe 
### (see https://magrittr.tidyverse.org/reference/pipe.html)

library("expss")

load("LFS_ILO_2021_Q1_CAL.RData")
str(LFS_ILO_CAL)

### calculate ilo status using design weights

LFS_ILO_CAL %>%
  tab_cols(ilo_lfs , total()) %>%
  tab_rows(REGION, total()) %>%
  tab_weight(DESIGN_WEIGHT) %>%
  tab_stat_sum %>%
  tab_pivot()

### calculate ilo status using final weights

LFS_ILO_CAL %>%
  tab_cols(ilo_lfs , total()) %>%
  tab_rows(REGION, total()) %>%
  tab_weight(FINAL_WEIGHT) %>%
  tab_stat_sum %>%
  tab_pivot()
